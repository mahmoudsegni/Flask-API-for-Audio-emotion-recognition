import numpy as np
from flask import Flask, request, render_template,redirect,jsonify
import joblib
import tensorflow as tf
import librosa 
import os
import requests
# from utils import *
import requests
import random
import string
from flask import Flask, request, render_template,redirect,jsonify
# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# print(f"Device: {device}")
folder_name="data_chunks"
from werkzeug.utils import secure_filename
from datasets import load_dataset
from transformers import pipeline
classifier = pipeline("audio-classification", model="superb/hubert-base-superb-er")
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = r'.\Upload'

@app.route('/', methods=['GET', 'POST']) 


def index():
    y = ""
    pred_list=[]
    confidence_list=[]
    
    
    
    
    file=True
    # wav_url="https://d358byuyocunuy.cloudfront.net/5a93bea5-3e2a-4ad7-926b-37eee1e493f2/ff10ae7d-fef1-4990-ae71-c9c1c61ebaa6-recording-2021-03-28--18-27-34.wav"
    wav_url=request.get_json()
    # wav_path=''.join(random.choice(string.ascii_lowercase) for i in range(10))
    wav_path="./Upload/file"
        # run the url request 
    r = requests.get(wav_url, allow_redirects=True) 
    # Save the wav file
    open(wav_path, 'wb').write(r.content)

    
    
    
    
    
    
    
    
    
    
    # if request.method == "POST": 
    #     print("FORM DATA RECEIVED")
    #     if "file" not in request.files:  # no file uploaded
    #         print(" Cannot find file")
    #         return redirect(request.url)
    #     file = request.files["file"]
    #     filename = secure_filename(file.filename)
    #     file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename)) # if file exist, give that file
    #     if file.filename == "":  # if file is empty, return to the main page
    #         print(" Uploaded file is empty")
    #         return redirect(request.url)
    #     if file:
    #         print(" Your file successfully uploaded")
    #         path=os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if file:
        print(" Your file successfully uploaded")
        labels = classifier(wav_path)
        print(labels)

            
    data={"emotion":labels[0:3]}
    return jsonify(data)

if __name__ == '__main__':
    app.run( port=5000, debug=True) # multiple requests at the same time for the file
