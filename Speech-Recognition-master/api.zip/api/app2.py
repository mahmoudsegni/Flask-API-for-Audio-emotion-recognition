import numpy as np
import pandas as pd

from pathlib import Path
from tqdm import tqdm

import torchaudio
from sklearn.model_selection import train_test_split

import os
import sys



from werkzeug.utils import secure_filename

from flask import Flask, request, render_template,redirect,jsonify
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = r'.\Upload'

@app.route('/', methods=['GET', 'POST']) 


def index():

    y = ""
    df_new = pd.DataFrame()
    pred_list=[]
    confidence_list=[]
#     file=True
    if request.method == "POST": 
        print("FORM DATA RECEIVED")
        if "file" not in request.files:  # no file uploaded
            print(" Cannot find file")
            return redirect(request.url)
        file = request.files["file"]
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename)) # if file exist, give that file
        if file.filename == "":  # if file is empty, return to the main page
            print(" Uploaded file is empty")
            return redirect(request.url)
#     if file:
#         print(" Your file successfully uploaded")
#         path=request.get_json()
#         print(path['0']['0'])
#             path=os.path.join(app.config['UPLOAD_FOLDER'], filename)

        if file:
            print(" Your file successfully uploaded")
            path=os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
     
#     data={"emotion":df_new}
    return jsonify({"emotion":"success"})

if __name__ == '__main__':
#     global df_new
#     app.run( port=8080, debug=True)
    app.run(host='0.0.0.0')  # multiple requests at the same time for the file
