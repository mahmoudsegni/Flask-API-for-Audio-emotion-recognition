import requests
import json
from argparse import ArgumentParser
import pandas as pd
import random

parser = ArgumentParser(add_help=True)



# parser.add_argument('--fileUrl',  default='https://d358byuyocunuy.cloudfront.net/5a93bea5-3e2a-4ad7-926b-37eee1e493f2/ff10ae7d-fef1-4990-ae71-c9c1c61ebaa6-recording-2021-03-28--18-27-34.wav')
parser.add_argument('--fileUrl',default='https://d358byuyocunuy.cloudfront.net/5a93bea5-3e2a-4ad7-926b-37eee1e493f2/ff10ae7d-fef1-4990-ae71-c9c1c61ebaa6-recording-2021-03-28--18-27-34.wav')
parser.add_argument('--host_port', type=str, default='5000')
hparams = parser.parse_args()
# path=hparams.input_file_path
# df=pd.DataFrame([path])
# a_file = open(path, "r")
# d = json.load(a_file)b  b bbvbvbbvbbvb v  v
#d={'amount':[hparams.amount],'region':[hparams.region],'onboarding_start':[hparams.date_of_onboarding_start],'onboarding_finished':[hparams.date_of_onboarding_finished], 'request_result':[hparams.response_for_the_last_request] }
# data=pd.DataFrame(d,index=[0])

#df.region = le.transform(data.region)
# data['onboarding_start']=pd.to_datetime(data['onboarding_start'])
# data['onboarding_finished']=pd.to_datetime(data['onboarding_finished'])
# year_a=data['onboarding_start'].dt.year
# year_b=data['onboarding_finished'].dt.year
# print(year_b,year_a)
# data['onboarding_period']=0
# data['onboarding_period'][0]=(abs(data['onboarding_finished'][0]-data['onboarding_start'][0])).days
# data=data.drop(columns=['onboarding_start','onboarding_finished'])





data = hparams.fileUrl
url = 'http://localhost:'+hparams.host_port+'/'

j_data = json.dumps(data)
headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
r = requests.post(url, data=j_data, headers=headers)
print(r, r.text)
