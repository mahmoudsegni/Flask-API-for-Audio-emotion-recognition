import librosa
from librosa import display
import os
import shutil
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Flatten
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.applications.resnet50 import decode_predictions
import os
import pandas as pd
import numpy as np 
import math as mt
import matplotlib.pyplot as plt
import joblib
# importing libraries 
import keras
import os
import json
from werkzeug.utils import secure_filename
import numpy as np
#from flask import Flask, request, jsonify, render_template
from tensorflow import keras
import pickle
import joblib
import numpy as np
from keras.models import model_from_json
import librosa 
from tqdm import tqdm, tqdm_pandas
import pandas as pd
import os 
from pydub import AudioSegment
from pydub.silence import split_on_silence
encoder=joblib.load(r'models/onehot.joblib')
from keras.models import load_model
model = load_model(r'models/conv2d_mfcc_aug.h5')
images_folder="mel_images"
sampling_rate=44100
audio_duration=2.5
n_mfcc = 30

# create a speech recognition object
'''
2. Extracting the MFCC feature as an image (Matrix format).  
'''
def prepare_data(df, n, aug, mfcc):
    X = np.empty(shape=(df.shape[0], n, 216, 1))
    input_length = sampling_rate * audio_duration
    
    cnt = 0
    for fname in tqdm(df.Path):
        file_path = fname
        data, _ = librosa.load(file_path, sr=sampling_rate
                               ,res_type="kaiser_fast"
                               ,duration=2.5
                               ,offset=0.5
                              )

        # Random offset / Padding
        if len(data) > input_length:
            max_offset = len(data) - input_length
            offset = np.random.randint(max_offset)
            data = data[offset:(input_length+offset)]
        else:
            if input_length > len(data):
                max_offset = input_length - len(data)
                offset = np.random.randint(max_offset)
            else:
                offset = 0
            data = np.pad(data, (offset, int(input_length) - len(data) - offset), "constant")

        # Augmentation? 
        if aug == 1:
            data = speedNpitch(data)
        
        # which feature?
        if mfcc == 1:
            # MFCC extraction 
            MFCC = librosa.feature.mfcc(data, sr=sampling_rate, n_mfcc=n_mfcc)
            MFCC = np.expand_dims(MFCC, axis=-1)
            X[cnt,] = MFCC
            
        else:
            # Log-melspectogram
            melspec = librosa.feature.melspectrogram(data, n_mels = n_melspec)   
            logspec = librosa.amplitude_to_db(melspec)
            logspec = np.expand_dims(logspec, axis=-1)
            X[cnt,] = logspec
            
        cnt += 1
    
    return X

# a function that splits the audio file into chunks
# and applies speech recognition
def get_large_audio_transcription(path):
    """
    Splitting the large audio file into chunks
    and apply speech recognition on each of these chunks
    """
    # open the audio file using pydub
    sound = AudioSegment.from_wav(path)  
    # split audio sound where silence is 700 miliseconds or more and get chunks
    chunks = split_on_silence(sound,
        # experiment with this value for your target audio file
        min_silence_len = 500,
        # adjust this per requirement
        silence_thresh = sound.dBFS-14,
        # keep the silence for 1 second, adjustable as well
        keep_silence=500,
    )
    folder_name="data_chunks"
    # create a directory to store the audio chunks
    if not os.path.isdir(folder_name):
        os.mkdir(folder_name)
    whole_text = ""
    # process each chunk 
    for i, audio_chunk in enumerate(chunks, start=1):
        # export audio chunk and save it in
        # the `folder_name` directory.
        chunk_filename = os.path.join(folder_name, f"chunk{i}.wav")
        audio_chunk.export(chunk_filename, format="wav")
    
    
def remove_old_chunks(folder_name):
    path, dirs, files = next(os.walk(folder_name))
    file_count = len(files)
    # return the text for all chunks detected
    print(file_count)
    for f in files:
        print(f)
        os.remove(os.path.join(folder_name,f))
    
    path, dirs, files = next(os.walk(folder_name))
    file_count = len(files)
    print(file_count)

def remove_old_images(folder_name):
    path, dirs, files = next(os.walk(folder_name))
    file_count = len(files)
    # return the text for all chunks detected
    print(file_count)
    for f in files:
        print(f)
        os.remove(os.path.join(folder_name,f))
    
    path, dirs, files = next(os.walk(folder_name))
    file_count = len(files)
    print(file_count)


def create_mel_images():
    
    if not os.path.isdir(images_folder):
        os.mkdir(images_foldes)

    #make use of the new files
    pred_list=[]
    paths, dirs, files = next(os.walk(r"./data_chunks"))

    for i in range(len(files)):
        x, sr = librosa.load(os.path.join(r"./data_chunks",files[i]), sr=22050)      # loading audio file using librosa module 
        S = librosa.feature.melspectrogram(x, sr=sr, n_mels=128)                 # converting audio file to mel-spectrogram 
        log_S = librosa.power_to_db(S, ref=np.max)
        librosa.display.specshow(log_S, sr=sr, x_axis='time', y_axis='mel')
        fig1 = plt.gcf()
        fig1.savefig(os.path.join(r"./mel_images", f"fig{i}.png"))


def load_mel_images():
    data=[]
    paths, dirs, files = next(os.walk(r"./mel_images"))

    for i in range(len(files)):

        image = load_img(os.path.join(r"./mel_images",files[i]), target_size=(224, 224))
        # convert the image pixels to a numpy array 
        image = img_to_array(image) 
        # reshape data for the model
        image = image.reshape((image.shape[0], image.shape[1], image.shape[2]))
        # prepare the image for the VGG model
        image = preprocess_input(image)
        data.append(image)
    return(data)



 
def most_frequent(List):
    counter = 0
    num = List[0]
     
    for i in List:
        curr_frequency = List.count(i)
        if(curr_frequency> counter):
            counter = curr_frequency
            num = i
 
    return num